#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

#define ll long long
vector<ll> numbers;

void write_to_console(ll n, ll period){
    cout << "Num of elements u want to see:" << n << endl << endl << "Period = " << period << endl << endl << "First n numbers : [ " ;
    for(ll i = 0; i < n; i++){
        cout << numbers[i % numbers.size()];
        if (i != n - 1 ) cout << ", ";
    }
    cout << " ]" << endl;
}

void write_to_file(ll n, ll period){
    ofstream myfile;
    myfile.open ("output.txt");
    myfile << "Num of elements u want to see:" << n << endl << endl << "Period = " << period << endl << endl ;
    
//    myfile << "All numbers : [ ";
//    for(ll i = 0; i < numbers.size(); i++){
//        myfile << numbers[i];
//        if (i != numbers.size() - 1 ) myfile << ", ";
//    }
//    myfile << " ]" << endl << endl ;
    myfile << "First n numbers : [ ";
    
    for(ll i = 0; i < n; i++){
        myfile << numbers[i % numbers.size()];
        if (i != n - 1 ) myfile << ", ";
    }
    myfile << " ]" << endl;
    myfile.close();
}

ll find_numbers(ll m, ll a, ll c){
    
    ll i = 0;
    
    while(true){
        ll x = (numbers[i] * a + c) % m;
        
        if (x == numbers[0]){
            break;
        }
        else{
            numbers.push_back(x);
            i++;
        }
    }
    
    return numbers.size();
}

int main() {
    
    // enter n - num of elements you want to see
    cout << "Enter num of elements you want to see : ";
    ll n; cin >> n;
    
    // enter m, a, c, X0
    ll m = pow(2, 25) - 1;
    ll a = pow(12, 3);
    ll c = 987;
    numbers.push_back(11);
    
    ll period = find_numbers(m, a, c);
    write_to_file(n, period);
    
    return 0;
}
