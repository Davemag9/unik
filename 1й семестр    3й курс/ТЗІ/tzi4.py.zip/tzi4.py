import time

from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_v1_5

# Генерація ключів
start_time = time.time()
n = 1024
key = RSA.generate(n)
end_time = time.time()
elapsed_time0 = end_time - start_time

# Збереження приватного ключа
private_key = key.export_key()
with open("private_key.pem", "wb") as f:
    f.write(private_key)

# Збереження публічного ключа
public_key = key.publickey().export_key()
with open("public_key.pem", "wb") as f:
    f.write(public_key)

# Завантаження ключів з файлів
with open("private_key.pem", "rb") as f:
    private_key = RSA.import_key(f.read())

with open("public_key.pem", "rb") as f:
    public_key = RSA.import_key(f.read())


with open("video.mp4", "rb") as file:
    message = file.read()

start_time = time.time()
cipher_rsa = PKCS1_v1_5.new(public_key)

res = []
i = 0
block_size = public_key.size_in_bytes() - 11
while True:
    block = message[i*block_size:(i+1)*block_size]
    if not block:
        break
    i+=1
    res += cipher_rsa.encrypt(block)
end_time = time.time()


with open("res.txt", "wb") as file:
    file.write(bytes(res))


with open("res.txt", "rb") as file:
    message = file.read()


elapsed_time1 = end_time - start_time

# Розшифрування повідомлення
start_time = time.time()
cipher_rsa = PKCS1_v1_5.new(private_key)

res = []
i = 0

while True:
    block = message[i*128:(i+1)*128]
    if not block:
        break
    i+=1
    res += cipher_rsa.decrypt(block, sentinel = '4ert')

with open("res1.txt", "wb") as file:
    file.write(bytes(res))

# decrypted_message = cipher_rsa.decrypt(message)
end_time = time.time()
elapsed_time2 = end_time - start_time

# print(decrypted_message)
print(f"RSA make key time: {'%.5f' % elapsed_time0} seconds")
print()
print(f"RSA encode time: {'%.5f' % elapsed_time1} seconds")
print()
print(f"RSA decode time: {'%.5f' % elapsed_time2} seconds")
