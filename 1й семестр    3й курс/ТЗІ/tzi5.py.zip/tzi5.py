from Crypto.PublicKey import DSA
from Crypto.Signature import DSS
from Crypto.Hash import SHA256

def gen_new_keys():
    key = DSA.generate(2048)

    public_key = key.publickey().export_key(format='PEM')
    with open("public_key.pem", "wb") as f:
        f.write(public_key)

    private_key = key.export_key(format='PEM')
    with open("private_key.pem", "wb") as f:
        f.write(private_key)

def read_keys():
    with open("private_key.pem", "rb") as f:
        private_key = DSA.import_key(f.read())

    with open("public_key.pem", "rb") as f:
        public_key = DSA.import_key(f.read())

    return private_key, public_key

def make_sign(private_key, message):

    hash_obj = SHA256.new(message)

    signer = DSS.new(private_key, 'fips-186-3')
    signature = signer.sign(hash_obj)

    with open("output.txt", 'w') as file:
        file.write(signature.hex())
    print("Check output.txt")

def check_sign(public_key, message):
    with open("output.txt", 'r') as file:
        signature = bytes.fromhex(file.read())

    hash_obj = SHA256.new(message)
    verifier = DSS.new(public_key, 'fips-186-3')

    if(not verifier.verify(hash_obj, signature)):  
        print ("The message is authentic.")
    else:
        print ("The message is not authentic.")

    
# print("Generate new keys?😈  (1/0)")
# n = input()
# if n == '1':
#     print("🤭🤭🤭🤭")
#     gen_new_keys()

print("Menu:")
print("1. Sign from keyboard.")
print("2. Sign from file.")
print("3. Verify from keyboard.")
print("4. Verify from file.")
print("Input choise: ", end='')

n = int(input())
private_key, public_key = read_keys()

if n == 1:
    message = input().encode('ascii')
    make_sign(private_key=private_key, message=message)
elif n == 2:
    with open("video.mp4", "rb") as file:
        message = file.read()
    make_sign(private_key=private_key, message=message)
elif n == 3:
    message = input().encode('ascii')
    check_sign(public_key=public_key, message=message)
elif n == 4:
    with open("video.mp4", "rb") as file:
        message = file.read()
    check_sign(public_key=public_key, message=message)
else:
    print("🤡")

