
# def kruskal_dist(field):
#     new_list = []

#     for i in range(len(field)):
#         for j in range (len(field)):
#             d = abs(field[i][0] - field[j][0]) + abs(field[i][1] - field[j][1])
#             new_list.append((d, (i, j)))

#     return sorted(new_list)


# def kurwaskal(field):
#     field = list(field)
#     if not field:
#         return 0
    
#     new_list = kruskal_dist(field)

#     n = len(field)
#     m = len(new_list)

#     cost = 0
#     drevo = [0] * n

#     for i in range(n):
#         drevo[i] = i

#     for i in range(m):
#         a = new_list[i][1][0]
#         b = new_list[i][1][1]
#         l = new_list[i][0]

#         if drevo[a] != drevo[b]:
#             cost += l
#             old = drevo[b]
#             new = drevo[a]
#             for j in range(n):
#                 if drevo[j] == old:
#                     drevo[j] = new
                    
#     return cost