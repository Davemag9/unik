#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define ld long double

class Transport{
protected:
    string cbrand;
    string cmodel;
    int cWIN;


public:
    void COUT(){
        cout << cbrand << endl;
    }
    virtual void Shoto()=0;

    Transport(string aBrand, string aModel, int aWIN )
            : cbrand(aBrand), cmodel(aModel), cWIN(aWIN){}
};

class Service{
protected:
    string cowner;
    string cproblem;
    int cDaysToSolve;

public:

    Service(string aOwner, string aProblem, int aDaysToSolve)
            : cowner(aOwner), cproblem(aProblem), cDaysToSolve(aDaysToSolve){}

};

class Car:public Transport,public Service{
private:
    string cColor;
    double cWeight;

public:
    Car(string aBrand, string aModel, int aWIN, string aOwner, string aProblem, int aDaysToSolve, string aColor)
            : Transport(aBrand, aModel, aWIN), Service(aOwner, aProblem, aDaysToSolve), cColor(aColor){}
    void PRINT(){cout<<cbrand<<endl<<cmodel<<endl<<cWIN<<endl<<cowner<<endl<<cproblem<<endl<<cDaysToSolve<<endl<<cColor<<endl;}

    virtual void Shoto() override {
        return BestWayToSolveTheProblem();
    }

    void getWeight(){
        cin>>cWeight;
        if (cWeight - (long long int) cWeight == 0)Weight((long long int) cWeight);
        else Weight(cWeight);
    }
    void BestWayToSolveTheProblem(){
        int k;
        srand(time(NULL));
        k = rand() % 3;

        if (k == 0) cout << "Zroby klumbu" << endl;
        if (k == 1) cout << "Proday polyakam, kupi Volvo na Lytovskih blyahah" << endl;
        if (k == 2) cout << "Razbey ob stenku" << endl;
    }
    void Weight(double aCarWeight){cout<<aCarWeight<<endl;}
    void Weight(long long int aCarWeight){cout<<aCarWeight<<endl;}
};

int main(){
    Car automobil("Mercedes","AMEGE",661538495,"Lukashenko Bat`ko Minskyi","Check",INFINITY,"Service GRUNTOWKA");

    automobil.PRINT();
    automobil.getWeight();
    cout<<"Best Way To Solve The Problem:"<< endl;
    automobil.Shoto();
}