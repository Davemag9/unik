#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define ld long double

class Transport{
protected:
    string cBrand;
    string cModel;

public:

    Transport(string aBrand, string aModel)
    : cBrand(aBrand), cModel(aModel){}

    string getBrand(){
        return cBrand;
    }
    string getModel(){
        return cModel;
    }
    void setBrand(string str){
        cBrand = str;
    }
    void setModel(string str){
        cModel = str;
    }
    virtual void Print(){
        cout << "Brand:  " << getBrand() << endl << "Model:  " << getModel() << endl;
    }
};

class Car: public Transport{
protected:
    string cType;
    string cPlate;
public:
    Car(string aBrand, string aModel, string aType, string aPlate)
    : Transport(aBrand, aModel), cType(aType), cPlate(aPlate) {}

    string getType(){
        return cType;
    }
    string getPlate(){
        return cPlate;
    }
    void setType(string str){
        cType = str;
    }
    void setPlate(string str){
        cPlate = str;
    }
    void Print() override {
        cout << "Brand:  " << getBrand() << endl << "Model:  " << getModel() << endl << "Type:  " << getType() << endl << "Plate:  " << getPlate() << endl;
    }
};

class Problem{
protected:
    string cProblem;
    string cDeadline;
public:
    Problem(string aProblem)
    : cProblem(aProblem){}

    string getProblem(){
        return cProblem;
    }
    void setProblem(string str){
        cProblem = str;
    }

    string getDeadline(){
        return cDeadline;
    }
    void setDeadline(string str){
        cDeadline = str;
    }


    Problem(string aProblem, string aDeadline)
            : cProblem(aProblem), cDeadline(aDeadline){}

};

class Service:public Car, public Problem {
private:
    string cOwner;
    string cName;
public:
    string getOwner(){
        return cOwner;
    }
    void setOwner(string str){
        cOwner = str;
    }
    string getName(){
        return cName;
    }
    void setName(string str){
        cName = str;
    }

    void isOpen() {
        cout << endl << "Service '" << cName << "' is open from 10:00 to 17:30. " << endl;
    }

    void isClosed() {
        cout << endl << "Service '" << cName << "' is open from 10:00 to 16:00, Now is 18:55, chose another one.  " << endl;
    }

    Service(string aModel, string aBrand, string aType, string aPlate, string aProblem, string aDeadline, string aOwner, string aName)
    : Car(aBrand, aModel, aType, aPlate), Problem(aProblem, aDeadline), cOwner(aOwner), cName(aName){}

    string ChooseService(){
        cout << "1) TYKAMI" << endl << "2) MaShInKa" << endl << "3) Polski remont" << endl << "4) STO u dyadi Toli" << endl;
        cout << "Chose service:" << endl;

        int a;
        cin >> a;

        if (a == 1){
            setName("TYKAMI");
            isOpen();
            cout << endl << endl;
            return getName();
        }
        else if (a == 2){
            setName("MaShInKa");
            isOpen();
            cout << endl << endl;
            return getName();
        }
        else if (a == 3){
            setName("Polski remont");
            isOpen();
            cout << endl << endl;
            return getName();
        }
        else if (a == 4){
            setName("STO u dyadi Toli");
            isClosed();
            cout << endl << endl;
            return ChooseService();
        }
        else{
            cout << ":/" << endl;
            return ChooseService();
        }
    }

    void ChooseAnotherCar() {
        cout << "Select car u want to take for repair time:" << endl;
        cout << "1) Ford MONDEO" << endl << "2) DEWOO Lanos" << endl << "3) Renault Clio" << endl;
        int a;
        cin >> a;
        if (a == 1) {
            cout << "You take Ford Mondeo." << endl << "Good luck, we wait for you in " << cDeadline << " days." << endl;
            return;
        } else if (a == 2) {
            cout << "You take DEWOO Lanos." << endl << "Good luck, we wait for you in " << cDeadline << " days." << endl;
            return;
        } else if (a == 3) {
            cout << "You take Renault Clio." << endl << "Good luck, we wait for you in " << cDeadline << " days."
                 << endl;
            return;
        } else {
            cout << ":/" << endl;
            ChooseAnotherCar();
        }
    }

    void Print() override{
        cout << "Brand:  " << getBrand() << endl << "Model:  " << getModel() << endl;
        cout << "Type:  " << getType() << endl << "Plate:  " << getPlate() << endl;
        cout << "Service Name:  " << getName() << endl;
        cout << "Deadline(days):  " << getDeadline() << endl << "Owner:  " << getOwner() <<endl;
    }
};

int main(){
    Transport automobile("","");
    Car mashina("", "", "", "");

    string str1, str2, str3, str4;
    cout << " Brand: ";
    cin >> str1;
    cout << "Model: ";
    cin >> str2;
    cout << "Type: ";
    cin >> str3;
    str4 = "BC 2661 HE";
    cout << endl;

    automobile.setBrand(str1);
    automobile.setModel(str2);
    mashina.setBrand(str1);
    mashina.setModel(str2);
    mashina.setType(str3);
    mashina.setPlate(str4);

    automobile.Print();
    cout << endl;
    mashina.Print();
    cout << endl;

    //------------------------------------------------------------------------------------------------------------------

    Problem one("");
    Problem two("","");

    string str5, str6;
    cout << " Problem: ";
    cin >> str5;
    cout << "Deadline(days): ";
    cin >> str6;
    cout << endl;

    one.setProblem(str5);
    two.setProblem(str5);
    two.setDeadline(str6);

    cout << "Problem:  " << one.getProblem() << endl;
    cout << endl;
    cout << "Problem:  " << two.getProblem() << endl << "Deadline(days):  "<< two.getDeadline() << endl;
    cout << endl;

    //------------------------------------------------------------------------------------------------------------------

    Service car("","","","","","","","");

    car.setName(car.ChooseService());


    string str7;
    cout << "Owner name: ";
    cin >> str7;
    cout << endl;

    car.setBrand(str1);
    car.setModel(str2);
    car.setType(str3);
    car.setPlate(str4);
    car.setProblem(str5);
    car.setDeadline(str6);
    car.setOwner(str7);
    car.Print();

    cout << endl << endl;
    car.ChooseAnotherCar();
}